package remote;

public class remot_operations implements remote_meth
{
    public void switchon()
    {
        System.out.println("Welcome to TVS-ky");
    }
    public void switchoff()
    {

    }
    public void ngc()
    {
        System.out.println("This is NGC Channel.");
    }
    public void discovery()
    {
        System.out.println("This is Discovery Channel.");
    }
    public void starssports()
    {
        System.out.println("This is StarsSports Channel.");
    }
    public void starmovies()
    {
        System.out.println("This is StarsSports Channel.");
    }
}