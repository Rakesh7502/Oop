package remote;

public interface remote_meth
{
    void switchon();
    void switchoff();
    void starssports();
    void ngc();
    void starmovies();
    void discovery();
}