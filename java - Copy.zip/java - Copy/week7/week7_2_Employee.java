
abstract class Employee{
    abstract double getamount();
}

class weeklyemployeed extends Employee{
    int no_of_weeks,total_weeks;
    double wage_per_week;
    weeklyemployeed(int nw,int w,double wage){
        this.no_of_weeks=nw;
        this.total_weeks=w;
        this.wage_per_week=wage;
    }
    String getname(){
        return "weeklyemployeed";
    }

    double getamount(){
        return (total_weeks*wage_per_week)-((total_weeks-no_of_weeks)*wage_per_week);
    }
}

class hourlyemployeed extends Employee{
    int no_of_hours,total_hours;
    double wage_per_hour;
     hourlyemployeed(int nw,int w,double wage){
        this.no_of_hours=nw;
        this.total_hours=w;
        this.wage_per_hour=wage;
    }
    String getname(){
        return "hourlyemployeed";
    }

    double getamount(){
        return (total_hours*wage_per_hour)-((total_hours-no_of_hours)*wage_per_hour);
    }
    
}
public class week7_2_Employee{
    public static void main(String[] args) {
        hourlyemployeed hr=new hourlyemployeed(24, 16, 150);
        System.out.println("amount to be paid to"+hr.getname()+"="+hr.getamount());
         weeklyemployeed wr=new weeklyemployeed(5, 4, 1200);
        System.out.println("amount to be paid to"+wr.getname()+"="+wr.getamount());
    

        
    }

}