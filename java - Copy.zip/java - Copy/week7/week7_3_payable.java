package week7;
import java.lang.*;
import java.util.Scanner;


/**
 * Innerweek7_3_payable
 */
 interface payable {
     double getamount();
}

class invoice implements payable{
    double salary;
    invoice(double s){
        this.salary=s;
    }

    public double getamount(){
        return salary;
    }
}
class Employee implements payable{
    double salary;
    Employee(double s){
        this.salary=s;
    }

    public double getamount(){
        return salary;
    }
}
class Students{
    public static int length;
    int id;
}

public class week7_3_payable{
    public static void main(String[] args) {
        // Scanner sc=new Scanner(System.in);
        // System.out.println("enter any number");
        // int a=sc.nextInt();
        // System.out.println(a);
        Students student[]=new Students[2];
        Students s1=new Students();
         Students s2=new Students();
         s1.id=2455;
         s2.id=2228;

        
//         int nums[]=new int[3];
// ;        nums[0]=5;
//         nums[1]=6;
//         nums[2]=8;
        for(int i=0;i<student.length;i++){
            System.out.println(student[i].id+" ");
        }
    }
    
   
}