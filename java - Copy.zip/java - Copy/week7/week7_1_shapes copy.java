package week7;
abstract class Shape{
   abstract double calculatearea();
   abstract double calculatevolume();
}

class circle extends Shape{
    double radius;
    circle(double r){
        this.radius=r;
    }

    String getShape(){
        return "circle";
    }
    double calculatearea(){
        return 3.14*radius*radius;
    }

    double calculatevolume(){
        return 2*3.14*radius;
    }

}

class square extends Shape{
    double side;
    square(double s){
        this.side=s;
    }

      String getShape(){
        return "square";
    }
    double calculatearea(){
        return side*side;
    }

    double calculatevolume(){
        return 4*side;
    }
}

class cube extends Shape{
    double s;
    cube(double s){
        this.s=s;
    }

      String getShape(){
        return "cube";
    }
    double calculatearea(){
        return 6*s*s;
    }

    double calculatevolume(){
        return 12*s;
    }
}

class sphere extends Shape{
    double s;
    sphere(double s){
        this.s=s;
    }

      String getShape(){
        return "sphere";
    }
    double calculatearea(){
        return 4*3.14*s*s;
    }

    double calculatevolume(){
        return (4 / 3) * 3.14 * s* s * s;
    }
}

public class week7_1_shapes{
    public static void main(String[] args) {
        circle c=new circle(3);
        
        System.out.println("area of"+c.getShape()+"="+c.calculatearea());
        System.out.println("volume of"+c.getShape()+"="+c.calculatevolume());
        square s=new square(5);
        System.out.println("area of"+s.getShape()+"="+s.calculatearea());
         System.out.println("volume of"+s.getShape()+"="+s.calculatevolume());
        cube cb=new cube(5);
         System.out.println("area of"+cb.getShape()+"="+cb.calculatearea());
         System.out.println("volume of"+cb.getShape()+"="+cb.calculatevolume());
         sphere sp=new sphere(3);
          System.out.println("area of"+sp.getShape()+"="+sp.calculatearea());
         System.out.println("volume of"+sp.getShape()+"="+sp.calculatevolume());

    }


}