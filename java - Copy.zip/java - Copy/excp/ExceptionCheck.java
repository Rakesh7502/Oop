import java.util.*;
import java.io.*;
import java.io.FileReader;
import java.lang.*;

public class ExceptionCheck {
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        try {
            // ArithmeticException
            int b;
            b = s.nextInt(); // b==0
            int a = 9 / b;
            System.out.println(a);

            // NullPointerException
            String st = null;
            int len = st.length();
            System.out.println(st);

            // ArrayIndexOutOfBound
            int[] arr = { 2, 3, 4 };
            int ele = arr[5];
            System.out.println("ArrayIndexOutOfBoundsException");

            // IOException
            // readFromFile("nonexistence_file.txt");

        } catch (ArithmeticException ae) {
            System.out.println(ae.getMessage());
        } catch (ArrayIndexOutOfBoundsException ab) {
            System.out.println(ab);
        } catch (NullPointerException np) {
            System.out.println(np.getMessage());
            // } catch (IOException ie) {
            // System.out.println(ie.getMessage());
            // }

        }
    }
}
