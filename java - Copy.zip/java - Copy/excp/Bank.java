// package bank;

import java.util.*;
import java.lang.*;

interface banking {
    String un = "bhavani";
    String p = "bhavs";

    public void checkcred(String user, String pass) throws invalidCredentials;

    public void credit(double amt);

    public void debit(double amt) throws invalidBal;

    public void display();

    public String exit(String r);
}

class invalidCredentials extends Exception {
    public invalidCredentials(String msg) {
        super(msg);
    }
}

class invalidBal extends Exception {
    public invalidBal(String msg) {
        super(msg);
    }
}

class Bank implements banking {
     static Scanner s = new Scanner(System.in);
    static double bal;
    static String un, p;

    public void credit(double amt) {
        bal += amt;
    }

    public void checkcred(String us, String pass) throws invalidCredentials {
        if ((un).equals(us) == false || (p).equals(pass) == false)
            throw new invalidCredentials("invalidCredentials exist");
    }

    public void debit(double amt) throws invalidBal {
        if (bal < amt)
            throw new invalidBal("insufficient balance");
        else
            bal -= amt;
    }

    public void display() {
        System.out.println("bal=" + bal);
    }

    public String exit(String resp) {
        if (resp.equalsIgnoreCase("yes"))
            return "yes";
        else
            return "no";
    }

    public static void main(String[] args) {
        Bank b = new Bank();
        double amt = 0;
        System.out.println("enter initial bal=");
        bal = s.nextDouble();
        System.out.println("enter username,password=");
        un = s.next();
        p = s.next();
        String exitResp = "no";
        while (true) {
            System.out.println("choose ant trans=");
            String ch = s.next();
            switch (ch) {

                case "credit":
                    System.out.println("enter amt to credit=");
                    amt = s.nextDouble();
                    b.credit(amt);
                    break;
                case "checkcredential":
                    System.out.println("enter use,pass=");
                    String u = s.next();
                    String p = s.next();
                    try {
                        b.checkcred(u, p);
                    } catch (invalidCredentials e) {
                        System.out.println(e.getMessage());
                    }
                    break;
                case "debit":
                    System.out.println("enter amt to debit=");
                    amt = s.nextDouble();
                    try {
                        b.debit(amt);
                    } catch (invalidBal e) {
                        System.out.println(e.getMessage());
                    }
                    break;
                case "display":
                    b.display();
                    break;
                case "exit":
                    exitResp = b.exit("yes");
                    break;

            }
            if (exitResp.equalsIgnoreCase("yes")) {
                System.out.println("transactions completed");
                break;
            }

        }
    }
}
