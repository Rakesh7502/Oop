package week6;
import java.util.*;
class Employee{
   private String first_name, last_name;
    double salary;

    Employee(String f_name,String l_name){
        this.first_name=f_name;
        this.last_name=l_name;
    }

    String getFirstName(){
        return first_name;
    }
    String getLastName(){
        return last_name;
    }
}


class ContractEmployee extends Employee{
   private String department;
  private String designation;
  ContractEmployee(String first_name,String last_name,String depart,String desig,Double s){
    super(first_name,last_name);
    this.department=depart;
    this.designation=desig;
    salary=s;
  }

   void displayFullName(){
    System.out.println("FullName:"+getFirstName()+getLastName());
   }
   String getDepartment(){
    return department;
   }
   String  getDesignation(){
    return designation;
   }

   Double getsalary(){
    return salary;
 
   }
   void setdepart(String d){
    department=d;
   }
   void setdesig(String d){
    designation=d;
   }

}
class RegularEmployee extends Employee{

     private String department;
  private String designation;
  RegularEmployee(String first_name,String last_name,String depart,String desig,Double s){
    super(first_name,last_name);
    this.department=depart;
    this.designation=desig;
    salary=s;
  }

   void displayFullName(){
    System.out.println("FullName:"+getFirstName()+getLastName());
   }
   String getDepartment(){
    return department;
   }
   String  getDesignation(){
    return designation;
   }

   Double getsalary(){
    return salary;
 
   }
   void setdepart(String d){
    department=d;
   }
   void setdesig(String d){
    designation=d;
   }
}



public class week6_3 {
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        ContractEmployee ce=new ContractEmployee("Rakesh","Bhukya","IT","manager",80000.00);
        ce.displayFullName();
        ce.setdepart("CSE");
        System.out.println("department:"+ce.getDepartment());
        System.out.println("designation:"+ce.getDesignation());
        System.out.println("Salary:"+ce.getsalary());
        
    }

    
}
