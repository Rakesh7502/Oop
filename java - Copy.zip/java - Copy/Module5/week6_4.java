//package week6;
 class ContractEmployee{
    String name,department;
    ContractEmployee(String name,String depart){
        this.name=name;
        this.department=depart;
    }
}
class HourlyEmployee extends ContractEmployee{
   int no_of_hours;
   double wages_per_hr;


    HourlyEmployee(String name, String depart) {
        super(name, depart);
        //TODO Auto-generated constructor stub
    }
    
    public String getName() {
        return  name;
    }

    Double getsalary(){
        return no_of_hours*wages_per_hr;
    }

    String getDesig(){
        return "Hourly Employee";
    }
    String getdepart(){
       return super.department;
    } 

}
class WeeklyEmployee extends ContractEmployee{
     int no_of_weeks;
   double wages_per_week;


    WeeklyEmployee(String name, String depart) {
        super(name, depart);
        //TODO Auto-generated constructor stub
    }
    

    String getName() {
        return name;
    }

   Double getsalary(){
        return no_of_weeks*wages_per_week;
    }

    String getDesig(){
        return "Weekly Employee";
    }
    String getdepart(){
       return super.department;
    } 

}
class week6_4{
    public static void main(String[] args) {
        HourlyEmployee hr=new HourlyEmployee("sai","research");
        hr.wages_per_hr=500;
        hr.no_of_hours=240;
        System.out.println("employee Name:"+hr.getName());
        System.out.println("department:"+hr.getdepart());
        System.out.println("designation:"+hr.getDesig());
        System.out.println("salary :"+hr.getsalary());
        WeeklyEmployee wr=new WeeklyEmployee("Rakesh","marketing");
        wr.wages_per_week=5000;
        wr.no_of_weeks=5;
        System.out.println("\n");
        System.out.println("employee Name:"+wr.getName());
        System.out.println("department:"+wr.getdepart());
        System.out.println("designation:"+wr.getDesig());
        System.out.println("salary :"+wr.getsalary());

    }
}

