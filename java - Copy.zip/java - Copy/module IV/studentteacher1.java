//import module IV;
import java.util.ArrayList;
class Person {
    private String name;
    private String address;

    public Person(String name, String address) {
        this.name = name;
        this.address = address;
    }

    public String getName() {
        return name;
    }

    public String getAddress() {
        return address;
    }
}

class Student extends Person {
    private ArrayList<Course> coursesTaken;

    public Student(String name, String address) {
        super(name, address);
        coursesTaken = new ArrayList<>();
    }

    public void addCourseWithGrade(String courseName, int grade) {
        if (coursesTaken.size() < 30) {
            Course course = new Course(courseName, grade);
            coursesTaken.add(course);
        } else {
            System.out.println("Cannot add more than 30 courses.");
        }
    }

    public void printAllCoursesAndAverageGrade() {
        System.out.println("Courses taken by " + getName() + ":");
        for (Course course : coursesTaken) {
            System.out.println(course.getName() + " - Grade: " + course.getGrade());
        }

        double averageGrade = calculateAverageGrade();
        System.out.println("Average Grade: " + averageGrade);
    }

    private double calculateAverageGrade() {
        if (coursesTaken.isEmpty()) {
            return 0.0;
        }

        int totalGrade = 0;
        for (Course course : coursesTaken) {
            totalGrade += course.getGrade();
        }

        return (double) totalGrade / coursesTaken.size();
    }
}

class Teacher extends Person {
    private ArrayList<String> coursesTaught;

    public Teacher(String name, String address) {
        super(name, address);
        coursesTaught = new ArrayList<>();
    }

    public void addCourseTaught(String courseName) {
        if (coursesTaught.size() < 5) {
            coursesTaught.add(courseName);
        } else {
            System.out.println("Cannot teach more than 5 courses concurrently.");
        }
    }

    public void removeCourseTaught(String courseName) {
        coursesTaught.remove(courseName);
    }

    public void printAllCoursesTaught() {
        System.out.println("Courses taught by " + getName() + ":");
        for (String course : coursesTaught) {
            System.out.println(course);
        }
    }
}

class Course {
    private String name;
    private int grade;

    public Course(String name, int grade) {
        this.name = name;
        this.grade = grade;
    }

    public String getName() {
        return name;
    }

    public int getGrade() {
        return grade;
    }
}

public class studentteacher1{
    public static void main(String[] args) {
        // Example usage
        Student student = new Student("John Doe", "123 Main St");
        student.addCourseWithGrade("Math", 90);
        student.addCourseWithGrade("English", 85);
        student.printAllCoursesAndAverageGrade();

        Teacher teacher = new Teacher("Ms. Smith", "456 Oak St");
        teacher.addCourseTaught("Physics");
        teacher.addCourseTaught("Chemistry");
        teacher.printAllCoursesTaught();
    }
}


