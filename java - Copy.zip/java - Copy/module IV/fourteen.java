import java.util.Scanner;

class Books{
    String b_name;
    String A_name;
    int cnt;
    Books(String a,int b){
        this.b_name=a;
        this.cnt=b;
    }
}

class customer{
    int c_id;
    String c_name;
    String c_add;
    customer(int a,String b){
        this.c_id=a;
        this.c_name=b;
    }
}
public class fourteen {
    public static void main(String[] args) {
        Books[] b =new Books[3];
        b[0]=new Books("physics",5);
        b[1]=new Books("english",3);
        b[2]=new Books("telugu",4);
        System.out.println("enter book name you want to buy:");
        Scanner sc=new Scanner(System.in);
        String bk=sc.next();

        for(int i=0;i<b.length;i++){
            //System.out.println("helllo");

            if(bk.equals(b[i].b_name)){
            System.out.println("book found and quantity available:"+b[i].cnt);
            System.out.println("enter how many books you wnat");
            int q=sc.nextInt();
            if(q<b[i].cnt){
                b[i].cnt-=q;
                System.out.println("purchase done");
            }
            else{
                System.out.println("there is no your required quantity");
            }
            }

            }
        }
  
        
    }
    

