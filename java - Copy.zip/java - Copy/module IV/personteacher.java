class person{
    String name;
    String address;
    person(String name,String add){
        this.name=name;
        this.address=add;
    }

    String getname(){
        return name;
    }
    String getaddress(){
        return address;
    }

    void setaddress(String newadd){
        address=newadd;
    }

}
class student extends person{
    int numcourses=0;
    String[] courses;
    int[] grades;

    student(String name,String add){
        super(name,add);
    }

    void addcourseGrade(String course,int grade){
        String 
    }

}
class teacher extends person{

}

class personteacher{
    public static void main(String[] args) {
        
    }
}