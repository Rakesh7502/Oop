import java.util.Scanner;

class Products{
    int product_id;
    int product_q;
    String product_name;
    double product_price;
    Products(int id,double price){
        this.product_id=id;
        this.product_price=price;

    }


}
public class eleventh{
    public static void main(String[] args) {
        Products[] p=new Products[5];
        p[0]=new Products(1,99.90);
        p[1]=new Products(2,20.20);
        p[2]=new Products(3,6.87);
         p[3]=new Products(4,45.50);
          p[4]=new Products(5,40.49);
        Scanner c=new Scanner(System.in);
        double sum=0;
      for(int i=0;i<3;i++){
        int id,q;
        id=c.nextInt();
        q=c.nextInt();
        switch(id){
            case 1:
            sum+=p[0].product_price*q;
            break;
            case 2:
            sum+=p[1].product_price*q;
            break;
            case 3:
            sum+=p[2].product_price*q;
            break;
            case 4:
            sum+=p[3].product_price*q;
            break;

        }
      }
      System.out.println("total retail price:"+sum);   
    }

}