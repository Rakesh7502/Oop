import java.lang.*;
import java.util.*;
class string8{

	public static void main(String[]args)
	{

		Scanner s=new Scanner(System.in);
		System.out.println("enter string=");
		String s1=s.nextLine();
		System.out.println("UpperCase="+s1.toUpperCase());
		System.out.println("LowerCase="+s1.toLowerCase());
	}
}