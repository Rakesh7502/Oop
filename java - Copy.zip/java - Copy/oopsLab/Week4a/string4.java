import java.lang.*;
import java.util.*;

class string4 {

	public static void main(String[] args) {

		Scanner s = new Scanner(System.in);
		System.out.println("enter string=");
		String s1 = s.nextLine();
		int v = 0;
		for (int i = 0; i < s1.length(); i++) {
			char ch = s1.charAt(i);
			if (ch == 'a' || ch == 'A' || ch == 'e' || ch == 'E' || ch == 'i' || ch == 'I' || ch == 'o' || ch == 'O'
					|| ch == 'u' || ch == 'U')
				v++;
		}
		int c = s1.length() - v;
		System.out.println("num of vowels=" + v + ",num of consonants=" + c);
	}
}