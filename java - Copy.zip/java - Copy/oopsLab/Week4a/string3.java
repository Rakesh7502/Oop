import java.lang.*;
import java.util.*;
class string3{

	public static void main(String[]args)
	{

		Scanner s=new Scanner(System.in);
		System.out.println("enter string1=");
		String s1=s.nextLine();
		System.out.println("enter string2=");
		String s2=s.nextLine();
		System.out.println(s1.concat(s2));
	}
}