import java.lang.*;
import java.util.*;
class string2{

	public static void main(String[]args)
	{

		Scanner s=new Scanner(System.in);
		System.out.println("enter a string=");
		String s1=s.nextLine();
		System.out.println("enter a char=");
		char c=s.nextLine().charAt(0);
		int pos=s1.indexOf(c);
		System.out.println(pos);
		int c1=0;
		if(pos!=-1)
                   c1=1;
		
		while(pos>=0)
		{
			pos=s1.indexOf(c,pos+1);
			if(pos==-1)
			break;
			System.out.println(pos);
			c1=c1+1;
		}
		System.out.println("count="+c1);
	}
}