import java.lang.*;
class string{
	public static void main(String[]args)
	{
		String s1=new String("Bhavaniuhhyyg");
		String s2=new String("Bhavanikruthika");
		System.out.println(s1.compareTo(s2));
	}	
}