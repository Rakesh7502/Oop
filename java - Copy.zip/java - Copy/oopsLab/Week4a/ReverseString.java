import java.util.*;
public class ReverseString {
  public static void main(String[] args) {
    Scanner s=new Scanner(System.in);
    String s1=s.nextLine();
    String reversedString = "";
    
    for(int i = s1.length()-1; i>=0; i--){
      reversedString = reversedString + s1.charAt(i);
    }
    
    System.out.print("The reversed string of the '"+s1+"' is: " );
    System.out.println(reversedString);
  }
}