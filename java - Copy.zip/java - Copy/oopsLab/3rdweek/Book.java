import java.util.*;
import java.lang.*;

public class Book {
    String Bname, Bauthor;
    int Bcount;

    Book() {
    }

    Book(String Bname, String Bauthor, int Bcount) {
        this.Bname = Bname;
        this.Bauthor = Bauthor;
        this.Bcount = Bcount;
    }

    static void display(ArrayList<Book> b) {
        if (b.size() != 0) {
            for (Book n : b) {
                System.out.println("Bookname=" + n.Bname + " Bookauthor=" + n.Bauthor + " Bookcount=" + n.Bcount);
            }
        }
    }

    static Book exist(ArrayList<Book> b, String Bn) {
        Book s = new Book();
        for (Book obj : b) {
            if ((obj.Bname).equals(Bn))
                return obj;
        }
        return s;
    }

    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        System.out.println("enter num of books exist in book stall=");
        int n = s.nextInt();
        ArrayList<Book> b = new ArrayList<>(n);
        String Bn, Ba;
        int Bc;
        for (int i = 0; i < n; i++) {
            System.out.println("enter bookname=");
            Bn = s.next();
            System.out.println("enter bookauthor=");
            Ba = s.next();
            Bc = i + 1;
            b.add(new Book(Bn, Ba, Bc));
        }
        String exitPurchase = "no";
        while (true) {
            System.out.println("enter Bookname to purchase");
            Bn = s.next();
            Book present = exist(b, Bn);
            if (present.Bname != null) {
                b.remove(present);
                n--;
                System.out.println("num of remaining books=" + b.size());
                if (b.size() == 0)
                    System.out.println("no books exist in stall!!");
                else {
                    System.out.println("remaining books details=");
                    Book.display(b);
                }
            } else {
                System.out.println("required book not exist in stall!!");
            }
            if (b.size() == 0) {
                System.out.println("stall gets empty,no books exist to purchase!");
                break;
            }
            System.out.println("enter exitPurchase-> yes/no=");
            exitPurchase = s.next();
            if (exitPurchase.equals("yes")) {
                System.out.println("purchase completed!");
                break;
            }
        }
        System.out.println("");
    }

}
