import java.util.*;
import java.lang.*;

class emp {
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        System.out.println("enter num of emp=");
        int n = s.nextInt();
        String name[] = new String[n];
        int age[] = new int[n];
        char gen[] = new char[n];
        double sal[] = new double[n];
        String desig[] = new String[n];
        String add[] = new String[n];
        for (int i = 0; i < n; i++) {
            System.out.println("enter emp" + (i + 1) + "details:name,age,gender,salary,designation,address=");
            name[i] = s.next();
            age[i] = s.nextInt();
            gen[i] = s.next().charAt(0);
            sal[i] = s.nextDouble();
            desig[i] = s.next();
            add[i] = s.next();
        }
        for (int i = 0; i < n; i++) {
            int e_num = i + 1;
            System.out.println("emp " + e_num + " details are=");
            System.out.println("name=" + name[i] + ",age=" + age[i] + ",gender=" + gen[i] + ",salary=" + sal[i]
                    + ",designation=" + desig[i] + ",address=" + add[i]);
        }
    }
}