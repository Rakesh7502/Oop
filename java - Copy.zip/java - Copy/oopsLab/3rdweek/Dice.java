import java.util.Random;
import java.util.*;

public class Dice {
    public static void main(String[] args) {
        Random r = new Random();
        // int trial;
        int success = 0;
        for (int i = 0; i < 10; i++) {
            int trial1 = r.nextInt(6) + 1;// gives values[1,2,3,4,5,6] i.e; b/w 1-6
            try {
                Thread.sleep(1000);
            } catch (Exception e) {

            }
            int trial2 = r.nextInt(6) + 1;
            try {
                Thread.sleep(1000);
            } catch (Exception e) {
            }
            System.out.println("trail1=" + trial1 + "\ntrial2=" + trial2);
            if (trial1 == trial2)
                success++;
        }
        System.out.println("num of successful attempts=" + success);
    }
}
