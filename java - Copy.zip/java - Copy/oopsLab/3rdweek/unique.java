import java.util.*;

public class unique {
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        int c = 0;
        ArrayList<Integer> al = new ArrayList<>();
        while (c <= 5) {
            System.out.println("enter input=");
            int n = s.nextInt();
            if (n >= 10 && n <= 100) {
                if (c == 0) {
                    al.add(n);
                    c++;
                } else {
                    if (al.contains(n) == false)
                        al.add(n);
                    c++;
                }
            }
        }
        System.out.println("elements inculded=");
        for (Integer n : al) {
            System.out.print(n + " ");
        }
    }
}
