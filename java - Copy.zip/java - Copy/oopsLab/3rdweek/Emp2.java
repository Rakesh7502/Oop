import java.util.*;
import java.lang.*;

class details {
    String name, gender, designation, address;
    int age;
    double salary;

    details(String name, String gender, String designation, String address, int age, double salary) {
        this.name = name;
        this.age = age;
        this.gender = gender;
        this.salary = salary;
        this.designation = designation;
        this.address = address;
    }

    void display() {
        System.out.println("name=" + name + "\ngender=" + gender + "\ndesignation" + designation + "\naddress" + address
                + "\nage" + age + "\nsalary" + salary);
    }
}

class Emp2 {
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        System.out.println("enter num of employees=");
        int n = s.nextInt();
        details[] d = new details[n];
        for (int i = 0; i < n; i++) {
            System.out.println("enter employee details=");
            System.out.println("enter name,gender,designation,address,age salary of employee" + (i + 1));
            String name = s.next();
            String gender = s.next();
            String designation = s.next();
            String address = s.next();
            int age = s.nextInt();
            double salary = s.nextDouble();
            d[i] = new details(name, gender, designation, address, age, salary);
            System.out.println("displayinf emp" + (i + 1) + "details=");
            d[i].display();
        }
    }
}
