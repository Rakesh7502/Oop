interface Fare {
    double getAmt();
}

class bus implements Fare {
    double amt;

    bus(double amt) {
        this.amt = amt;
    }

    public double getAmt() {
        return amt;
    }
}

class train implements Fare {
    double amt;

    train(double amt) {
        this.amt = amt;
    }

    public double getAmt() {
        return amt;
    }
}

class test {
    public static void main(String[] args) {
        bus b = new bus(70);
        train t = new train(30);
        System.out.println(b.getAmt());
        System.out.println(t.getAmt());
    }
}
