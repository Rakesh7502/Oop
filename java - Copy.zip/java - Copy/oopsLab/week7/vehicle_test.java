interface vehicle {
    String getColor();

    int getNum();

    double getConsumption();
}

class TwoWheeler implements vehicle {
    String color;
    int num;
    int kilometer, liters;
    double consumption;

    TwoWheeler(String color, int num, int kilometer, int liters) {
        this.color = color;
        this.kilometer = kilometer;
        this.liters = liters;
        this.num = num;
    }

    public String getColor() {
        return color;
    }

    public int getNum() {
        return num;
    }

    public double getConsumption() {
        consumption = (double) kilometer / (double) liters;
        return consumption;
    }
}

class FourWheeler implements vehicle {
    String color;
    int num;
    int kilometer, liters;
    double consumption;

    FourWheeler(String color, int num, int kilometer, int liters) {
        this.color = color;
        this.kilometer = kilometer;
        this.liters = liters;
        this.num = num;
    }

    public String getColor() {
        return color;
    }

    public int getNum() {
        return num;
    }

    public double getConsumption() {
        consumption = (double) kilometer / (double) liters;
        return consumption;
    }
}

class vehicle_test {
    public static void main(String[] args) {
        TwoWheeler t1 = new TwoWheeler("blue", 8530, 23, 4);
        System.out.println(t1.getColor());
        System.out.println(t1.getConsumption());
        System.out.println(t1.getNum());
        FourWheeler t2 = new FourWheeler("red", 7722, 45, 5);
        System.out.println(t2.getColor());
        System.out.println(t2.getConsumption());
        System.out.println(t2.getNum());
    }
}
