import java.util.Scanner;
import java.lang.String;

class Account {
    private double balance;

    Account(double initialbalance) {
        if (initialbalance > 1000)
            this.balance = initialbalance;
        else
            System.out.println("balance must be greater than 1000");
    }

    void credit(double b) {
        balance += b;
        System.out.println(balance);
    }

    void debit(double b) {
        if (b <= balance)
            balance = balance - b;
        else {
            System.out.println("insufficient money= withdrawal amt > acct_bal");
        }
    }

    double getBalance() {
        return balance;
    }

    public void exit() {

    }

}

class BankingApp {
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        String Bank_name;
        String Branch_name;
        String Acct_name;
        int Acct_no = 0;
        double Acct_bal;
        String exitResponse;
        Account[] acc = new Account[10];// basar,nizambab each 5 accts
        // int B_index=0;
        // int N_index=5;
        int index = -1;
        System.out.println("enter num of accounts to create=");
        int numofaccts = s.nextInt();
        while (Acct_no != numofaccts) {
            // input prompt by user

            System.out.println("enter Bank_name=");
            Bank_name = s.next();
            System.out.println("enter Branch_name=");
            Branch_name = s.next();
            System.out.println("enter Acct_name=");
            Acct_name = s.next();
            System.out.println("enter initial amount=");
            Acct_bal = s.nextDouble();
            acc[++index] = new Account(Acct_bal);
            Acct_no++;
            double amt = 0;

            while (true) {
                exitResponse = "no";
                System.out.println("choose any transaction:");
                System.out.println("1=credit\n2=debit\n3=getbalance\n4=exit()");
                int transaction = s.nextInt();
                switch (transaction) {
                    case 1:
                        System.out.println("enter amt to credit=");
                        amt = s.nextDouble();
                        acc[index].credit(amt);
                        break;
                    case 2:
                        System.out.println("enter amt to debit=");
                        amt = s.nextDouble();
                        acc[index].debit(amt);
                        break;
                    case 3:
                        System.out.println("Leftover balance in Account" + Acct_name + "=" + acc[index].getBalance());
                        break;
                    case 4:
                        System.out.println("choosed transaction is completed!!");
                        exitResponse = "yes";
                        break;
                    default:
                        System.out.println("choose a valid transaction!!");
                }

                if (exitResponse.equalsIgnoreCase("yes") == true)
                    break;
            }
        }
        System.out.println("num of accounts existed till now=" + Acct_no);
    }
}
