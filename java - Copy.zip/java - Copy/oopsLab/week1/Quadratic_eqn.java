import java.util.Scanner;
import java.lang.Math;

class Quadratic_eqn {
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        System.out.println("enter a,b,c values as coeffients=");
        int a = s.nextInt();
        int b = s.nextInt();
        int c = s.nextInt();
        int disc = (b * b) - (4 * a * c);
        double root1 = 0, root2 = 0, real = 0, imag = 0;
        if (disc == 0) {
            root1 = root2 = (-b) / (2 * a);
            System.out.println(root1 + "," + root2);
        } else if (disc > 0) {
            root1 = ((-b) + (Math.sqrt(disc))) / (2 * a);
            root2 = ((-b) - (Math.sqrt(disc))) / (2 * a);
            System.out.println(root1 + "," + root2);
        } else {
            real = (-b) / (2 * a);
            imag = (Math.sqrt(-disc)) / (2 * a);
            // System.out.println("root1=" + real + "+i" + (imag) + ",root2=" + real + "-i"
            // + imag);
            System.out.printf("root1=%.2f+i %.2f, root2=%.2f-i %.2f", real, imag, real, imag);
        }
    }
}