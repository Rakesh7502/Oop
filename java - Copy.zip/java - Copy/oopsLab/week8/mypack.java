package p1;

public class mypack {
    public void show() {
        System.out.println("inside mypack");
    }
}
// compile: compile each file seperately -> (javac -d . filename.java), compile
// main method existing file also
// run: java mainmethod_pack.mainmethod_class