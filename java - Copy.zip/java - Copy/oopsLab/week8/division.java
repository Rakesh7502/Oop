package calculator;

public class division {
    public void divide(int x, int y) {
        try {
            int res = x / y;
            System.out.println(res);
        } catch (ArithmeticException e) {
            System.out.println(e);
        }
    }
}
