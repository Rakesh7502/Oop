package org.shapes;

public class square {
    public void Area(int s) {
        System.out.println("area of square=" + s * s);
    }
}
