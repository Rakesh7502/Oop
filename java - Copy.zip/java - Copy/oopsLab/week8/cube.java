package org.shapes;

public class cube {
    public void area(int s) {
        System.out.println("area of cube=" + 6 * s * s);
    }
}
