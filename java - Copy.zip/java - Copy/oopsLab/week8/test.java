package p2;

import p1.*;

public class test {
    public static void main(String[] args) {
        mypack m1 = new mypack();
        m1.show();
        mypack2 m2 = new mypack2();
        m2.show();
        mypack3 m3 = new mypack3();
        m3.show();
    }
}
