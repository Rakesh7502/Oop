package org.shapes;

public class circle {
    public void area(int r) {
        System.out.println("area of circle=" + (int) 3.14 * r * r);
    }
}
