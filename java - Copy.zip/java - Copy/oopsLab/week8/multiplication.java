package calculator;

public class multiplication {
    public void mul(int x, int y) {
        System.out.println(x * y);
    }
}
