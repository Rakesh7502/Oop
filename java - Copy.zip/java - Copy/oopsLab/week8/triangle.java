package org.shapes;

public class triangle {
    public void Area(int b, int h) {
        System.out.println("area of triangle=" + (0.5) * b * h);
    }
}
