package operation;

import calculator.*;

public class cal_operations {
    public static void main(String[] args) {
        addition a = new addition();
        a.add(3, 4);
        subtraction s = new subtraction();
        s.sub(9, 3);
        multiplication m = new multiplication();
        m.mul(5, 9);
        division d = new division();
        d.divide(9, 0);
    }
}
