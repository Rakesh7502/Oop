import java.util.*;

class test extends this_keyword {
    int n = 9;

    test(int n) {
        super(8);
        this.n = n;
        System.out.println(n);
    }
}

public class this_keyword {
    int n;

    this_keyword(int n) {
        this(n, 4.5);
        this.n = n;
        System.out.println(n);
    }

    this_keyword(int n, double k) {
        System.out.println("int=" + n + " float=" + k);
    }

    public static void main(String[] args) {
        this_keyword t = new test(4);
    }
}
