import java.util.*;

public class circle {
    static final double pi = 3.14;

    void Area(double r)//
    {
        System.out.println("Area of circle=" + (r * r * pi));
    }

    void perimeter(double r) {
        System.out.println("perimeter of circle=" + (2 * pi * r));
    }

    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        System.out.println("enter radius=");
        double r = s.nextDouble();
        circle c = new circle();
        c.Area(r);
        c.perimeter(r);
    }
}
