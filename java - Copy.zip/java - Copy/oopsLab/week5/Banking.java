import java.util.*;
import java.lang.*;

public class Account {
    double balance;

    Account() {
    }

    Account(double initialbalance) {
        if (initialbalance > 0)
            this.balance = initialbalance;
        else
            System.out.println("balance must be greater than 0");
    }

    void credit(double b) {
        balance += b;
    }

    void debit(double b) {
        if (balance >= b)
            balance -= b;
        else
            System.out.println("no sufficient amount to withdrawal in account");
    }

    double getBalance() {
        return balance;
    }
}

class Banking {
    public static void main(String[] args) {
        ArrayList<Account> ac = new ArrayList<>();
        Scanner s = new Scanner(System.in);
        String Acc_name = null, Acc_address = null;
        int Acct_no = 0;
        double Acc_bal = 0, bal = 0;
        String exitAcct_creation = "no";
        while (true) {
            System.out.println("enter account details=");
            System.out.println("enter Acct_name,Acct_address,Acct_bal");

            Acc_name = s.next();
            Acc_address = s.next();
            Acc_bal = s.nextDouble();

            Account obj = new Account(Acc_bal);
            ac.add(obj);
            Acct_no++;
            Account b = new Account();
            String exittrans = "no";
            while (true) {
                System.out.println("choose a transaction type");
                String ch = s.next();
                switch (ch) {
                    case "credit":
                        System.out.println("enter amt to credit=");
                        bal = s.nextDouble();
                        b = ac.get(Acct_no - 1);
                        b.credit(bal);
                        break;
                    case "debit":
                        System.out.println("enter amt to debit=");
                        bal = s.nextDouble();
                        b = ac.get(Acct_no - 1);
                        b.debit(bal);
                        break;
                    case "getbalance":
                        b = ac.get(Acct_no - 1);
                        System.out.println(b.getBalance());
                        break;
                    case "exit":
                        exittrans = "yes";
                        break;
                    default:
                        System.out.println("invalid transaction!");
                }
                if (exittrans.equalsIgnoreCase("yes")) {
                    System.out.println("transactions on account completed!");
                    break;
                } else {
                    System.out.println("enter exittrans yes/no");
                    exittrans = s.next();
                    if (exittrans.equalsIgnoreCase("yes")) {
                        System.out.println("transactions on account completed!");
                        break;
                    }
                }

            }
            if (exitAcct_creation.equalsIgnoreCase("yes")) {
                System.out.println("accounts creation completed!!");
                break;
            } else {
                System.out.println("enter exitAcct_creation yes/no=");
                exitAcct_creation = s.next();
                if (exitAcct_creation.equalsIgnoreCase("yes")) {
                    System.out.println("accounts creation completed!!");
                    break;
                }
            }
        }
        System.out.println("total num of accounts created=" + ac.size());
    }
}
