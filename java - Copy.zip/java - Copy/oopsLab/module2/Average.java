import java.util.Scanner;

class Average {
    static void caluclate_avg(int a, int b, int c) {
        double d = (a + b + c) / 3;
        System.out.println("avg=" +  d);
    }

    public static void main(String[] args) {

        Scanner s = new Scanner(System.in);
        System.out.println("enter three nums=");
        int a = s.nextInt();
        int b = s.nextInt();
        int c = s.nextInt();
        caluclate_avg(a, b, c);
    }
}