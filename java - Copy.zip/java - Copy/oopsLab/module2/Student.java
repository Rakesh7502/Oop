class Student {
    String name;
    int roll_no;

    Student(String name, int roll_no) {
        this.name = name;
        this.roll_no = roll_no;
    }

    String getName() {
        return name;
    }

    int getRoll_no() {
        return roll_no;
    }

    public static void main(String[] args) {
        Student s1 = new Student("john", 4);
        Student s2 = new Student("sam", 8);
        System.out.println("student1 name=" + s1.getName() + ",roll_num=" + s1.getRoll_no());
        System.out.println("student2 name=" + s2.getName() + ",roll_num=" + s2.getRoll_no());
    }
}