import java.util.*;

class Book {
    String Book_Name, Book_Author;
    int Book_count;

    Book() {
    }

    Book(String Bn, String Ba, int Bc) {
        Book_Name = Bn;
        Book_Author = Ba;
        Book_count = Bc;
    }
}

class cust {
    String cust_Name, cust_Address;
    int cust_Id;

    cust() {
    }

    cust(String Cn, String Ca, int Cid) {
        cust_Name = Cn;
        cust_Address = Ca;
        cust_Id = Cid;
    }
}

public class EBook_stall {
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        String Bn = null, Cn = null, Ca = null, Ba = null;
        int Cid = 0, n = 0, Bc = 0;
        System.out.println("enter num of books=");
        n = s.nextInt();
        Book B = new Book();
        for (int i = 1; i <= Bc; i++) {
            Bc = i;
            System.out.println("enter book details=>,name,author");
            Bn = s.next();
            Ba = s.next();
            new Book(Bn, Ba, Bc);
        }
        int Cc = 0;
        System.out.println("enter num of customers=");
        for (int i = 1; i <= Cc; i++) {
            Cid = i;
            System.out.println("enter customer details=>,name,address");
            Cn = s.next();
            Ca = s.next();
            new Book(Cn, Ca, Cid);
        }
    }
}