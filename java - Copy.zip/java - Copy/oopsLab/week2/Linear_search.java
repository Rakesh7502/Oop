import java.util.*;

public class Linear_search {
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        System.out.println("enter size=");
        int n = s.nextInt();
        int[] a = new int[n];
        System.out.println("enter elements=");
        for (int i = 0; i < n; i++) {
            a[i] = s.nextInt();
        }
        int flag = 0;
        System.out.println("enter ele to search=");
        int ele = s.nextInt();
        for (int i = 0; i < n; i++) {
            if (a[i] == ele) {
                flag = 1;
                System.out.println("ele:" + ele + " found");
                break;
            }
        }
        if (flag != 1)
            System.out.println("ele:" + ele + " not found");
    }
}