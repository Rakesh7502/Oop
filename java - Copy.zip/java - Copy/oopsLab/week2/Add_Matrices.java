import java.util.*;
import java.lang.Math;

public class Add_Matrices {
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        System.out.println("enter size of Matx1=");
        int r1 = s.nextInt();
        int c1 = s.nextInt();
        System.out.println("enter size of Matx2=");
        int r2 = s.nextInt();
        int c2 = s.nextInt();
        int[][] a = new int[r1][c1];
        int[][] b = new int[r2][c2];
        int[][] c = new int[r1][c2];

        if (r1 == r2 && c1 == c2) {
            System.out.println("enter matx1 ele=");
            for (int i = 0; i < r1; i++) {
                for (int j = 0; j < c1; j++) {
                    a[i][j] = (int) (Math.random() * 100);
                }
            }
            // for (int i = 0; i < r1; i++) {
            // for (int j = 0; j < c1; j++) {
            // System.out.println(a[i][j]);
            // }
            // }
            for (int n[] : a) {
                for (int m : n)
                    System.out.print(m + " ");
                System.out.println();
            }
            System.out.println("enter matx2 ele=");
            for (int i = 0; i < r1; i++) {
                for (int j = 0; j < c1; j++) {
                    b[i][j] = (int) (Math.random() * 100);
                }
            }
            for (int i = 0; i < r1; i++) {
                for (int j = 0; j < c1; j++) {
                    System.out.print(b[i][j] + " ");
                }
                System.out.println();
            }
            for (int i = 0; i < r1; i++) {
                for (int j = 0; j < c1; j++) {
                    c[i][j] = a[i][j] + b[i][j];
                }
            }
            System.out.println("Matrices addition =");
            for (int i = 0; i < r1; i++) {
                for (int j = 0; j < c1; j++) {
                    System.out.print(c[i][j] + " ");
                }
                System.out.println();
            }
        } else {
            System.out.println("matrix addition not possible!");
        }

    }
}