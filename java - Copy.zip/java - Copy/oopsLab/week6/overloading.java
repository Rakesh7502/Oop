public class overloading {
    void sum(int x, int y) {
        System.out.println("sum=" + (x + y));
    }

    void sum(double x, double y) {
        System.out.println("sum=" + (x + y));
    }

    void sum(int x, int y, int z) {
        System.out.println("sum=" + (x + y + z));
    }

    public static void main(String[] args) {
        overloading ol = new overloading();
        ol.sum(4, 5, 6);
        ol.sum(3, 4);
        ol.sum(3.3, 5.4);
    }
}
