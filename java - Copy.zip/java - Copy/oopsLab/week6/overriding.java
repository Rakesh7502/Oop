class Base {
    void sum(int x, int y) {
        System.out.println("inside Base");
        System.out.println(x + y);
    }
}

public class overriding extends Base {
    void sum(int x, int y) {
        System.out.println("inside derive");
        System.out.println(x + y);
    }

    public static void main(String[] args) {
        Base t = new overriding(); // child class overrides
        Base b = new Base();
        t.sum(3, 4);
        b.sum(3, 5);
    }
}
