import java.util.*;

public class Employee {
    String Fname, Lname;
    double salary;

    Employee(String Fname, String Lname) {
        this.Fname = Fname;
        this.Lname = Lname;
    }

    String getFname() {
        return Fname;
    }

    String getLname() {
        return Lname;
    }
}

class contractEmp extends Employee {
    private String desig, dept;

    contractEmp(double s, String Fname, String Lname, String dept, String desig) {
        super(Fname, Lname);
        this.dept = dept;
        this.desig = desig;
        salary = s;
    }

    void displayFullName() {
        System.out.println("fullname=" + getFname() + getLname());
    }

    String getDept() {
        return dept;
    }

    String getDesig() {
        return desig;
    }

    double getsalary() {
        return salary;
    }

    void setDept(String d) {
        dept = d;
    }

    void setDesig(String d) {
        desig = d;
    }
}

class regularEmp extends Employee {
    private String desig, dept;

    regularEmp(double s, String Fname, String Lname, String dept, String desig) {
        super(Fname, Lname);
        this.dept = dept;
        this.desig = desig;
        salary = s;
    }

    void displayFullName() {
        System.out.println("fullname=" + getFname() + getLname());
    }

    double getsalary() {
        return salary;
    }

    String getDept() {
        return dept;
    }

    String getDesig() {
        return desig;
    }

    void setDept(String d) {
        dept = d;
    }

    void setDesig(String d) {
        desig = d;
    }
}

class test {
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        contractEmp ec = new contractEmp(50000, "sri", "nayak", "cse", "HR");
        ec.displayFullName();
        ec.setDept("IT");
        System.out.println(ec.getDept());
        System.out.println(ec.getsalary());
        regularEmp er = new regularEmp(45000, "yamini", "netha", "ECE", "manager");
        er.displayFullName();
        er.setDesig("HR");
        System.out.println(er.getDesig());
        System.out.println(er.getsalary());
    }
}