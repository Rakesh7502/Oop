import java.util.*;

public class shape_poly {
    void area(double r) {
        final double pi = 3.14;
        System.out.println("area of circle=" + pi * r * r);
    }

    void area(float len, float wid) {
        System.out.println("area of rectangle=" + len * wid);
    }

    void Area(double side) {
        System.out.println("area of square=" + side * side);
    }

    void Area(double b, double h) {
        System.out.printf("area of triangle=%.2f", (0.5 * b * h));
    }

    public static void main(String[] args) {
        shape_poly s = new shape_poly();
        s.area(3.4);
        s.area(2.3f, 3.4f);
        s.Area(3);
        s.Area(2.3, 3.2);
    }
}