import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

// Vehicle super class
class Vehicle {
    String company;
    String model;
    double mileage;
    double fuelCapacity;
    double displacement;
    // Other common properties and methods

    // Constructor
    public Vehicle(String company, String model, double mileage, double fuelCapacity, double displacement) {
        this.company = company;
        this.model = model;
        this.mileage = mileage;
        this.fuelCapacity = fuelCapacity;
        this.displacement = displacement;
    }
}

// TwoWheeler sub-class
class TwoWheeler extends Vehicle {
    String frontBrake;
    String rearBrake;
    String tyreType;
    String headLamp;
    String userReviews;
    // Other properties specific to TwoWheeler

    // Constructor
    public TwoWheeler(String company, String model, double mileage, double fuelCapacity, double displacement,
            String frontBrake, String rearBrake, String tyreType, String headLamp, String userReviews) {
        super(company, model, mileage, fuelCapacity, displacement);
        this.frontBrake = frontBrake;
        this.rearBrake = rearBrake;
        this.tyreType = tyreType;
        this.headLamp = headLamp;
        this.userReviews = userReviews;
    }
}

// FourWheeler sub-class
class FourWheeler extends Vehicle {
    boolean airConditioner;
    boolean airBags;
    boolean powerSteering;
    boolean rainSensingWiper;
    // Other properties specific to FourWheeler

    // Constructor
    public FourWheeler(String company, String model, double mileage, double fuelCapacity, double displacement,
            boolean airConditioner, boolean airBags, boolean powerSteering, boolean rainSensingWiper) {
        super(company, model, mileage, fuelCapacity, displacement);
        this.airConditioner = airConditioner;
        this.airBags = airBags;
        this.powerSteering = powerSteering;
        this.rainSensingWiper = rainSensingWiper;
    }
}

// Main application class

class vehicleComparisionApp {
    public static void main(String[] args) {
        List<Vehicle> repository = new ArrayList<>();

        // Creating instances of TwoWheeler and FourWheeler and adding them to the
        // repository
        TwoWheeler bike1 = new TwoWheeler("Honda", "Activa", 45, 5, 110, "Disc", "Drum", "Tubeless", "LED", "Great");
        repository.add(bike1);

        FourWheeler car1 = new FourWheeler("Toyota", "Camry", 18, 60, 2500, true, true, true, true);
        repository.add(car1);

        // Getting user input for vehicle comparison
        Scanner scanner = new Scanner(System.in);
        System.out.println("Available vehicles for comparison:");
        for (Vehicle vehicle : repository) {
            System.out.println(vehicle.company + " " + vehicle.model);
        }
        System.out.println("Enter the company and model of the vehicle to compare: ");
        String userChoice = scanner.nextLine();

        // Comparing and the recommended vehicle to buy based on best mileage, fuel
        // capacity, displacement, and other properties
        Vehicle recommendedVehicle = null;
        double maxMileage = 0;
        double maxFuelCapacity = 0;
        double maxDisplacement = 0;
        for (Vehicle vehicle : repository) {
            if ((vehicle.company + " " + vehicle.model).equalsIgnoreCase(userChoice)) {
                if (vehicle.mileage > maxMileage && vehicle.fuelCapacity > maxFuelCapacity
                        && vehicle.displacement > maxDisplacement) {
                    maxMileage = vehicle.mileage;
                    maxFuelCapacity = vehicle.fuelCapacity;
                    maxDisplacement = vehicle.displacement;
                    recommendedVehicle = vehicle;
                }
            }
        }
        if (recommendedVehicle != null) {
            System.out.println("Recommended vehicle to buy based on best mileage, fuel capacity, and displacement: "
                    + recommendedVehicle.company + " " + recommendedVehicle.model);
        } else {
            System.out.println("No matching vehicle found.");
        }
    }
}
