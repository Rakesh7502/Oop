import java.util.*;

class Exception_rethrow {
    static void two() {
        String s = "abc";
        System.out.println(Integer.parseInt(s));
    }

    void one() {
        two();
        // try {
        //     two();
        // } catch (NumberFormatException e) {
        //     System.out.println("caught inside one() method");
        //     System.out.println(e);
        // }
    }

    public static void main(String[] args) {
        Exception_rethrow E = new Exception_rethrow();
        try {
            E.one();
        } catch (Exception e) {
            System.out.println("caught inside main() method");
            System.out.println(e);
        }
    }
}