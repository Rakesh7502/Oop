import java.util.*;

class MyException extends Exception {
    MyException(String msg) {
        super(msg);
    }
}

class ExceptionDemo {
    public static void main(String[] args) throws MyException {
        try {
            throw new MyException("myexception message");
        } catch (MyException e) {
            System.out.println(e);
            System.out.println(e.getMessage());
        } finally {
            System.out.println("finally block");
        }

    }
}