import java.util.*;

public class Catch_sequence {
    public static void main(String[] args) throws ArithmeticException {
        try {
            int c = 9 / 0;
        }

        catch (ArithmeticException e) {
            System.out.println(e);
            System.out.println(e.getMessage());
        }

        catch (Exception e) {
            System.out.println("Exception caught=" + e);
        }
        // catch (ArithmeticException e) {
        // System.out.println(e);
        // }
    }
}