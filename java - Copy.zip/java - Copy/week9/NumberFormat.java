public class NumberFormat {
    public static void main(String[] args) {
        String s = "ab";
        try {
            int n = Integer.parseInt(s);
        } catch (NumberFormatException e) {
            System.out.println("NmberFormatException caught!!");
            System.out.println(e.getMessage());
        }
    }
}
