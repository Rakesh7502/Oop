public class fifth {
    public static void main(String[] args) {
        try {
            int a=Integer.parseInt("a");
        } catch (Exception e) {
           System.out.println(e);
        }
    }
}
