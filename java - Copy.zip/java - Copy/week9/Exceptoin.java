
public class Exceptoin {

    public Exceptoin(String string) {
    }

}
