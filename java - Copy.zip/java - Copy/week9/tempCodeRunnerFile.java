catch (ArithmeticException e) {
            System.out.println(e);
        }