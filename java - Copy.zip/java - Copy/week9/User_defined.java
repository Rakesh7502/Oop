class UserException extends Exception {
    String msg;

    UserException(String msg) {
        super(msg);
        this.msg = msg;
    }

    void printMessage() {
        System.out.println("stored string=" + msg);
    }
}

public class User_defined {
    public static void main(String[] args) {
        try {
            throw new UserException("own Exception");
        } catch (UserException e) {
            System.out.println(e);
            System.out.println(e.getMessage());
            e.printMessage();
        }
    }
}
