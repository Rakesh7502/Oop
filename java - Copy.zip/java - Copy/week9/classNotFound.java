class classNotFound {
    public static void main(String[] args) {
        try {
            // trying to load non-existing class with name "pseudoClass"
            Class.forName("pesudoClass");
            System.out.println("end of try block");
        } catch (ClassNotFoundException e) {
            System.out.println(e);
            System.out.println(e.getMessage());
            // getMessage() is inbuilt fun which gives string msg exist in that class->
            // constructor
        }
    }
}