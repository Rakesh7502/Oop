package srinivas;

public class pacak_user {
    private void show(){
        System.out.println("learn coding");
    }
        public static void main(String args[]){
            pacak_user r=new pacak_user();
            r.show();
        }
    }

