class student{  // super
     protected int roll,marks;
    String name;
    protected void input(){
        System.out.println("enter  roll name,marks");
    }
}
class ankit extends student{  //sub-class
    void display()
    {
        roll=1 ;name="ankit";marks=89;
        System.out.println(roll + " " + name +" " + marks);
    }
}
 class simple_inheri{
    public static void main (String args[]){
        ankit r= new ankit();
        r.input(); r.display();
    }
}
