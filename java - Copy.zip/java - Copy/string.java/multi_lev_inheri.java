  class A{   // super class
    int a,b,c;
    void add(){
        a=10;b=20;
        c=a+b;
        System.out.println("sum of two numbers: " +c);
    }
    void sub(){
        a=100;b=200;
        c=a-b;
        System.out.println("sub of two numbers: " +c);
    }
  }
  class B extends A{   //sub 1 class
    void mul(){
        a=10;b=20;
        c=a*b;
        System.out.println("mul of two numbers" +c);
    }
    void div(){
        a=10;b=2;
        c=a/b;
        System.out.println("div of two numbers: "  +c);
    }      
  }
  class C extends B{
    void mod(){
        a=10;b=20;
        c=a%b;
        System.out.println("modulus of two numbers: " +c);
    }
  }
 class multi_lev_inheri {
    public static void main(String args[]){
        C r=new C();
        r.add(); r.sub(); r.mul(); r.div(); r.mod();
    }
    
}
