   class Laptop{

   }
   class Developer{
    public void develop(){
        System.out.println("coding");
    }
   }
class inter {
    public static void main(String args[]){
        Developer d= new Developer();
        srinivas.develop();
        System.out.println("srinivas");
    }
}
