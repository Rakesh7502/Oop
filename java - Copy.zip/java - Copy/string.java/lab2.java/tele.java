import java.util.*;
class TV{
	private int Channel;
	private int volumeLevel;
	private boolean on;
	public TV(int Channel,int volumeLevel,boolean on)
	{
		this.Channel=Channel;
		this.volumeLevel=volumeLevel;
		this.on=on;
	}
	public void turnOn()
	{
		on=true;
		System.out.println("Turns on the TV");
	}
	public void turnOff()
	{
		on=false;
		System.out.println("Turns off the TV");
	}
	public void setChannel(int newChannel)
	{
		if(on && newChannel>=1 && newChannel<=40)
		{
			Channel=newChannel;
			System.out.println("TV sets to channel number: "+newChannel);
		}
		else
			System.out.println("Channel is not available!");
	}
	public void setVolume(int newVolumeLevel)
	{
		if(on && newVolumeLevel>=1 && newVolumeLevel<=7)
		{
			volumeLevel=newVolumeLevel;
			System.out.println("TV sets to volume level: "+newVolumeLevel);
		}
		else
			System.out.println("Volume level is not available");
	}
	public void channelUp()
	{
		if(on && Channel<40)
		{
			Channel++;
			System.out.println("TV increases the Channel number to: "+Channel);
		}
		else
			System.out.println("Channel is not available!");
	}
	public void channelDown()
	{
		if(on && Channel>1)
		{
			Channel--;
			System.out.println("TV decreases the Channel number to: "+Channel);
		}
		else
			System.out.println("Channel is not available!");
	}
	public void volumeUp()
	{
		if(on && volumeLevel<7)
		{
			volumeLevel++;
			System.out.println("TV increases the volume Level to: "+volumeLevel);
		}
		else
			System.out.println("volume Level limit exceeded!");
	}
	public void volumeDown()
	{
		if(on && volumeLevel>1)
		{
			volumeLevel--;
			System.out.println("TV decreases the volume Level to: "+volumeLevel);
		}
		else
			System.out.println("volume can't decreases!");
	}
}
class tele{
	public static void main(String[] args)
	{
		int n;
		Scanner sc=new Scanner(System.in);
		TV t=new TV(1,1,false);
		while(true)
		{
			System.out.println("enter \n1.turn On\n2.turn Off\n3.set Channel\n4.set volume Level\n5.channelUp\n6.channelDown\n7.volumeUp\n8.volumeDown");
			n=sc.nextInt();
			switch(n)
			{
				case 1:
					t.turnOn();
					break;
				case 2:
					t.turnOff();
					break;
				case 3:
					System.out.println("enter channel number: ");
					int ch=sc.nextInt();
					t.setChannel(ch);
					break;
				case 4:
					System.out.println("enter volume number: ");
					int v=sc.nextInt();
					t.setVolume(v);
					break;
				case 5:
					t.channelUp();
					break;
				case 6:
					t.channelDown();
					break;
				case 7:
					t.volumeUp();
					break;
				case 8:
					t.volumeDown();
					break;
				default:
					System.out.println("Invalid choice");
					break;
			}
			if(n==2)
			{
				System.out.println("Exiting the TV");
				break;
			}
		}
	}
}
