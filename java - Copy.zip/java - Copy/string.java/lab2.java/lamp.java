public class lamp {
    private boolean ison;
    private String lamptype;
    public lamp(boolean ison ,String lamptype){
        this.ison=ison;
        this.lamptype=lamptype;

    }
    public void turnon(){
        ison=true;
        System.out.println(lamptype + "light is now on");
    }
    public void turnoff(){
        ison=false;
        System.out.println(lamptype + "light is now off");
    }
    public static void main(String[] args){
        lamp ledlamp=new lamp(false,"led");
        lamp halogenlamp=new lamp(false,"halogen");
        ledlamp.turnon();
        halogenlamp.turnon();
        ledlamp.turnoff();
        halogenlamp.turnoff();
    }
}
