import java.util.Scanner;
public class circle {
    private double radius;
    public circle(double radius){
        this.radius=radius;
    }
    public double getarea(){
        return Math.PI*radius*radius;
    }
    public double getperimeter(){
        return 2*Math.PI*radius;
    }
    public static void main(String[] args){
        Scanner scanner=new Scanner(System.in);
        System.out.println("enter the radius of the circle");
        double radius=scanner.nextDouble();
        circle mycircle=new circle(radius);
        double area=mycircle.getarea();
        System.out.println("area of the circle " + area);
        double perimeter=mycircle.getperimeter();
        System.out.println("perimeter of the circle " + perimeter);
    }
}
