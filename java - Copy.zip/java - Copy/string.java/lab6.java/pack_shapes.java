package shapes;
import shapes.*;
import java.util.Scanner;
public class square{
    private double side;
    public square(double side){
        this.side=side;
    }
    public double calculatearea(){
        return side*side;
    }
    public double calculateperimeter(){
        return 4*side;
    }
}

public class triangle{
    private double height;
     private double width;
      private double side1;
       private double side2;
        private double side3;
  public triangle(double height,double width,double side1,double side2,double side3){
    this.height=height;
    this.width=width;
    this.side1=side1;
    this.side2=side2;
    this.side3=side3;
  }
  public double calculatearea(){
    return 0.5*height*width;
  }
  public double calculateperimeter(){
    return side1*side2*side3;
  }
}
public class circle{
    private double radius;
    public circle (double radius){
        this.radius=radius;
    }
    public double calculatearea(){
        return Math.PI*radius*radius;
    }
    public double calculateperimeter(){
        return 2*Math.PI*radius*radius;
    }
}
public class pack_shapes {
    public static void main(String args[]){
        Scanner scanner=new Scanner(System.in);
        System.out.println("choose a shape 1.square 2.triangle 3.circle");
        int choice=scanner.nextInt();
        switch(choice){
            case 1:
            System.out.println("enter the side of a square");
            double squareside=scanner.nextDouble();
            square squares= new square(squareside);
            System.out.println("Area " + squares.calculatearea());
            System.out.println("perimeter " + squares.calculateperimeter());
            break;
            case 2:
             System.out.println("enter the radiuus of a circle");
            double circleradius=scanner.nextDouble();
            circle circles= new circle( circleradius);
            System.out.println("Area " + circles.calculatearea());
            System.out.println("perimeter " + circles.calculateperimeter());
            break;
            default:
            System.out.println("invalid input ");
        }
    }
}
