package dept;
import java.util.Scanner;
/**
 * pack_bran
 */

public class pack_bran {
    public static void main(String[] args) {
        System.out.println("hello world");
    }
}
// interface Department{
//    void displaySubjects();
// }
// class CSE implements Department{
//     public void displaySubjects(){
//         System.out.println("CSE subjects");
//         System.out.println("1. Algorithms");
//         System.out.println("2.COA");
//         System.out.println("3.DBMS");

//     }
// }
// class  ECE implements Department{
//     public void displaySubjects(){
//         System.out.println("ECE subjects");
//         System.out.println("1. DEC");
//         System.out.println("2.CS");
//         System.out.println("3.DSP");

//     }
// }
// class ME implements Department{
//     public void displaySubjects(){
//         System.out.println("ME subjects");
//         System.out.println("1. machines");
//         System.out.println("2.thermodynamics");
//         System.out.println("3.fluids machines");

//     }
// }
// class CE implements Department{
//     public void displaySubjects(){
//         System.out.println("CE subjects");
//         System.out.println("1. SA");
//         System.out.println("2.GE");
//         System.out.println("3.TE");

//     }
// }

// public class pack_bran {
//     public static void main(String[] args){
//         Scanner scanner= new Scanner(System.in);
//         System.out.println("enter the dept(cse,ece,me,ce)");
//         String department= scanner.nextLine().toUpperCase();
//         Department dept;
//         switch(department){
//             case "CSE":
//             dept=new CSE();
//             break;
//              case "ECE":
//             dept=new ECE();
//             break;
//              case "ME":
//             dept=new ME();
//             break;
//              case "CE":
//             dept=new CE();
//             break;
//             default:
//             System.out.println("Invalid department");
//             return;
//         }
//         dept.displaySubjects();
//         scanner.close();

//     }
// }
