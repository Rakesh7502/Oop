
class Bird{
    public void sing(){
        System.out.println("tweet tweet tweew");
    }
}
class Cow extends Bird{
    public void sing(){
        System.out.println("amba amba");
        Bird.sing();
    }
    public void perimeter(int s)
    {

    }
    public void perimeter(int l , int b)
}
class poly {
    public static void main(String args[]){
     Bird b= new Bird();
     b.sing();
     Cow  c= new Cow();
     c.sing();
    }
}
