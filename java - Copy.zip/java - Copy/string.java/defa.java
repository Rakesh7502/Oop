 class A{
    int a;String b;boolean c;
    A(){
        //a=100;b="srinivas";c=true;
    }
    void disp()
    {
        System.out.println(a+" "+b+" "+c);
    }
 }
public class defa {
    public static void main(String args[]){
    A r=new A();
    r.disp();
    }

}
