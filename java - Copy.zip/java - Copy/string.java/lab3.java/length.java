
import java.util.Scanner;
public class length {
    public static void main(String args[]){
        Scanner scanner=new Scanner(System.in);
        System.out.println("enter a string");
        String inputstring=scanner.nextLine();
        int result=inputstring.length();
        System.out.println("length of a string" + result);
        
    }
}
