import java.util.Scanner;

public class substring {
    public static void main(String args[]){
        Scanner scanner=new Scanner(System.in);
        System.out.println("enter a string");
        String userinput= scanner.nextLine();       
    }
    private static void findSubstring(String original){
        String substring=original.substring(1,5);
        System.out.println("Substring" + substring);
    }
    private static void checkstartwith(String original){
        String startwithenter=original.startwith("enter");
        System.out.println("start with enter" + startwithenter);
    }
    private static void checkendwith(String original){
        String endwithstring=original.endwith("string");
        System.out.println("end with string" + endwithstring);
    }
}
