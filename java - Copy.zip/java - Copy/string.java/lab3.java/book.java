import java.util.Scanner;
class books{
    private String bookname;
    private String bookauthor;
    private int bookcount;

public books(String name,String author,int count) {
    bookname=name;
    bookauthor=author;
    bookcount=count;
}
public String getbookname(){
    return bookname;
}
public int getbookcount(){
    return bookcount;
}
public void sellbook(){
    if(bookcount>0){
        bookcount--;
        System.out.println("book sold successfully " + bookcount);
    }
    else
    {
System.out.println("sorry the book is out of stock");
    }
}
}
class customer{
    private int customerid;
    private String customername;
    private String customeraddress;
    public customer(int id,String name,String address){
        customerid=id;
        customername=name;
        customeraddress=address;
    }
    public void buybook(books Book){
        System.out.println("Customer " + customername + " is buying");
        Book.sellbook();
    }
}
public class book {
   public static void main(String args[]){
    Scanner scanner= new Scanner(System.in);
    books samplebook=new books("sample book","sample author",5);
    customer customers= new customer(1,"john doe","123 main st");
    System.out.println("bookname" + samplebook.getbookname());
    System.out.println("bookcount" + samplebook.getbookcount());
    customers.buybook(samplebook);
    System.out.println("updated book count" + samplebook.getbookcount());

   }

}
