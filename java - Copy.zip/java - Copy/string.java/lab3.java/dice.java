import java.util.Random;
public class dice {
    public static void main(String[] args){
        int numberofattempts=10;
        int successfulattempts=0;
        
        for(int i=1;i<=numberofattempts;i++){
            int dice1=rolldice();
            int dice2=rolldice();
            System.out.println("Attempt" + i +"DICE 1" + dice1 + ",dice 2= " + dice2);
            if(dice1==dice2){
            successfulattempts++;
            System.out.println("successful attempts");
        }
        try{
            Thread.sleep(1000);
        }
        catch(InterruptedException e){
            e.printStackTrace();
        }
    }
    System.out.println("\nnumber of successful attempts" + successfulattempts);

    }
    private static int rolldice(){
        Random random=new Random();
        return random.nextInt(6)+1;
    }
    
}
