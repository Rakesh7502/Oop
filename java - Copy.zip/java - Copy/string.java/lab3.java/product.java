import java.util.Scanner;
public class product {
    public static void main(String args[]){
        Scanner scanner= new Scanner(System.in);
double product1price=99.90;
double product2price=20.20;
double product3price=6.87;
double product4price=45.50;
double product5price=40.49;
System.out.println("enter the number of product sold");
int numproducts=scanner.nextInt();
double totalretailvalue=0;
int i;
for(i=1;i<=numproducts;i++){
    System.out.println("\n enter the details for products " + i + ":");
    System.out.println("products ID(1-5)");
    int productid=scanner.nextInt();
    System.out.println("quantity sold:");
    int quantitysold=scanner.nextInt();
    switch(productid){
        case 1:
        totalretailvalue+=product1price*quantitysold;
        break;
        case 2:
        totalretailvalue+=product2price*quantitysold;
        break;
        case 3:
        totalretailvalue+=product3price*quantitysold;
        break;
        case 4:
        totalretailvalue+=product4price*quantitysold;
        break;
        case 5:
        totalretailvalue+=product5price*quantitysold;
        break;
       default:
        System.out.println("invalid product");
    }
}
System.out.println("\n total retail value of all products sold Rs. " + totalretailvalue);
    }
    
}
