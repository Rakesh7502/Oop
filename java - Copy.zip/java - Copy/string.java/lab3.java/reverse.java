import java.util.Scanner;

public class reverse {
    public static void main(String args[]){
        Scanner scanner=new Scanner(System.in);
            System.out.println("enter the string");
            String userinput=scanner.nextLine();
            String reversedstring=reverseString(userinput);
            System.out.println("reversed string " + reversedstring);
        }
           private static String reverseString(String original){
                int length= original.length();
                StringBuilder reversed=new StringBuilder();
                int i;
                for(i=length-1;i>=0;i--){
                    reversed.append(original.charAt(i));
                }
      return reversed.toString();
            }
    
    }
