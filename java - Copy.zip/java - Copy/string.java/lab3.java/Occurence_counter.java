import java.util.Scanner;
public class Occurence_counter{
    public static void main(String args[]) 
    {
        Scanner scanner= new Scanner(System.in);
        System.out.print("enter the text");
        String text=scanner.nextLine();
        System.out.println("enter an alphabet");
        char alphabet=scanner.next().charAt(0);
        text=text.toLowerCase();
        char lowercaseAlphabet=Character.toLowerCase(alphabet);
        int occurences=0;
        int index=text.indexOf(lowercaseAlphabet);
        while(index!=-1){
            occurences++;
            index=text.indexOf(lowercaseAlphabet,index + 1);
        }
        System.out.println("the alphabet " + alphabet + " occur " + occurences + " times in the text");
    }
}
