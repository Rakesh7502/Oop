interface customerraj{
    int amt=5;//public + static + final
    void purchase(); // public + abstract
}
class sellersanju implements customerraj {
    @Override
    public void purchase(){
        
        System.out.println("Raj needs " +amt+" kg rice");
    }
}
class inter_sanju{
   public static void main(String args[]){
       customerraj c= new sellersanju();
       c.purchase();
       System.out.println(customerraj.amt);
   }
}
