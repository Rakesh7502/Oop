import java.util.Scanner;
interface shape{
    double getarea();
    double getperimeter();
}
class circle implements shape{
    private double radius;
    circle(double radius){
        this.radius=radius;
    }
    public double getarea(){
        return Math.PI*radius*radius;
    }
    public double getperimeter(){
        return 2*Math.PI*radius;
    }
}
class square implements shape{
    private double side;
    square(double side){
        this.side=side;

    }
    public double getarea(){
        return side*side;
    }
    public double getperimeter(){
        return 4*side;
    }
}
class rectangle implements shape{
    private double length;
    private double width;
    rectangle(double length,double width){
        this.length=length;
        this.width=width;
    }
    public double getarea(){
        return length*width;
    }
    public double getperimeter(){
        return 2*(length+width);
    }
}
public class area_per {
    public static void main(String args[]){
        Scanner scanner=new Scanner(System.in);
        System.out.println("enter the radius of the circle");
        double circleradius=scanner.nextDouble();
        circle circle=new circle(circleradius);
         System.out.println("enter the side of the square");
        double squareside=scanner.nextDouble();
        square square=new square(squareside);
         System.out.println("enter the lengthof the rectangle");
         double rectanglelength=scanner.nextDouble();
          System.out.println("enter the widthof the rectangle");
        double rectanglewidth=scanner.nextDouble();
        rectangle rectangle =new rectangle(rectanglelength,rectanglewidth);
        System.out.println("\n results;");
        System.out.println("circle-area " + circle.getarea() + " perimeter " + circle.getperimeter());
         System.out.println("square-area " + square.getarea() + " perimeter " + square.getperimeter());
          System.out.println("rectangle-area " + rectangle.getarea() + " perimeter " + rectangle.getperimeter());
    }
}
