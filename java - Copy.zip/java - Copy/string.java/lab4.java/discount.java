import java.util.Scanner;
public class discount {
    public static void main(String args[]){
        Scanner scanner=new Scanner(System.in);
        System.out.println("enter the product name");
        String productname= scanner.nextLine();
        System.out.println("enter the company name");
        String companyname=scanner.nextLine();
        System.out.println("enter the quantity");
        int quantity=scanner.nextInt();
        double amazondis=getAmazonDis(quantity);
        double flipkartdis=getFlipkartDis(quantity);
     if(amazondis>flipkartdis){
        System.out.println("it is cost effective to buy from amazon");
        
     }
     else
      System.out.println("it is cost effective to buy from flipkart"); 
    }
    private static double getAmazonDis(int quantity){
        double discount=0.0;
        if(quantity>50000){
            discount=0.15;
        }
        else
        {
            discount=0.10;
        }
   return discount;
    }
     private static double getFlipkartDis(int quantity){
        double discount=0.0;
        if(quantity>30000){
            discount=0.05;
        }
        else
        {
           Scanner scanner= new Scanner(System.in);
           System.out.println("are you an rguktian");
           String isrguktstudent=scanner.nextLine();
           if(isrguktstudent.equalsIgnoreCase("yes")){
            discount=0.30;
           }
        }
   return discount; 
    }

}
