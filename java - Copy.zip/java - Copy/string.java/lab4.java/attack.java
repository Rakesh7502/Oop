import java.util.Scanner;
class monster{
    public void attack(){      
    }
}
class firemonster extends monster{
    public void attack(){
        System.out.println("attacking with fire");
    }
}
class watermonster extends monster{
    public void attack(){
        System.out.println("attacking with water");
    }
}
class rockmonster extends monster{
    public void attack(){
        System.out.println("attacking with rock");
    }
}

public class attack {
    public static void main(String args[]){
        monster m1=new firemonster();
        monster m2=new watermonster();
        monster m3=new rockmonster();
        m1.attack();
        m2.attack();
        m3.attack();
    }
}
