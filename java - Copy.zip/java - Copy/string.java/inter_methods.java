interface client{ // customer
    void webdesign();
    void webdevelope();
}
abstract class rajtech implements client{ // producer
    @Override
    public void webdesign(){
      System.out.println("green,top menu,three dot button");
    }
}
class rahultech extends rajtech{
   @Override
     public void webdevelope(){
        System.out.println("HTML,CSS,JAVASCRIPT");
     } 
    }
public class inter_methods {
    public static void main(String args[]){
    rahultech r= new rahultech();
    r.webdesign();
    r.webdevelope();
    }
}
