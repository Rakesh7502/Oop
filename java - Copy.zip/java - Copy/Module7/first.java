import java.util.*;
public class first {
    public static void main(String[] args) {
        try{
            Scanner cin=new Scanner(System.in);
            int a=cin.nextInt();
        }
        catch(Exception e)
        {
            System.out.println(e);
        }
    }
}
