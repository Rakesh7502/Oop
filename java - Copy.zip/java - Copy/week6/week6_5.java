class Vehicle{
    int vehile_no, insurance_no;
    String color;
    int getconsumption(){

    }

    void displayconsumption(){

    }
}

class TwoWheeler extends Vehicle{
    Double average;
    
    void maintenance(){

    }
    Double average(){

    }

}
class FourWheeler extends Vehicle{

}



public class week6_5 {
    public static void main(String[] args) {
        
    }
    
}
