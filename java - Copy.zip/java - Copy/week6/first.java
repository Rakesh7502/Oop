package week1;
import java.util.*;
class first{
    public static void main(String args[]){
        System.out.println("hello");
    }

}