package week6;
//POLYMORPHISM
class week6_1{
    void area(float x){
        System.out.println( "area of square"+x*x+"sq.units");
    }

    void area(float x,float y){
        System.out.println( "area of rectangle"+x*y+"sq.units"); 
    }
    void area(double x){
        System.out.println( "area of circle "+3.14*x*x+"sq.units"); 
    }


public static void main(String args[]){
    week6_1 obj=new week6_1();
    obj.area(3);
    obj.area(2,3);
    obj.area(3.5);
}
}